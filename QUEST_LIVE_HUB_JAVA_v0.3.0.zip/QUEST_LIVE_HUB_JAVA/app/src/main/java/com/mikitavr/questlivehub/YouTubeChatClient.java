package com.mikitavr.questlivehub;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class YouTubeChatClient implements ChatClient {
    public interface MessageSink { void accept(ChatMessage message); }
    public interface StatusSink { void accept(String status); }
    private final String liveChatId, token;
    private final MessageSink messages;
    private final StatusSink status;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean stopped = false;
    private String pageToken = "";
    private long pollDelay = 5000;

    public YouTubeChatClient(String liveChatId, String token, MessageSink messages, StatusSink status) {
        this.liveChatId = liveChatId == null ? "" : liveChatId.trim();
        this.token = token == null ? "" : token.trim();
        this.messages = messages; this.status = status;
    }

    @Override public void start() {
        if (liveChatId.isEmpty() || token.isEmpty()) {
            status.accept("YouTube requires liveChatId and OAuth access token."); return;
        }
        stopped = false;
        status.accept("YouTube: connecting…");
        worker.execute(this::pollLoop);
    }

    private void pollLoop() {
        main.post(() -> status.accept("YouTube: polling live chat"));
        while (!stopped) {
            HttpURLConnection connection = null;
            try {
                String query = "liveChatId=" + URLEncoder.encode(liveChatId, "UTF-8")
                        + "&part=snippet%2CauthorDetails&maxResults=200"
                        + (pageToken.isEmpty() ? "" : "&pageToken=" + URLEncoder.encode(pageToken, "UTF-8"));
                URL url = new URL("https://www.googleapis.com/youtube/v3/liveChat/messages?" + query);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
                connection.setRequestProperty("Authorization", "Bearer " + token);
                int code = connection.getResponseCode();
                if (code >= 400) throw new Exception("YouTube API HTTP " + code);
                StringBuilder raw = new StringBuilder();
                try (InputStream in = connection.getInputStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = reader.readLine()) != null) raw.append(line);
                }
                JSONObject data = new JSONObject(raw.toString());
                JSONArray items = data.optJSONArray("items");
                if (items != null) for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    JSONObject snippet = item == null ? null : item.optJSONObject("snippet");
                    JSONObject authorDetails = item == null ? null : item.optJSONObject("authorDetails");
                    String author = authorDetails == null ? "Unknown" : authorDetails.optString("displayName", "Unknown");
                    String text = snippet == null ? "" : snippet.optString("displayMessage", "");
                    if (!text.isEmpty()) {
                        ChatMessage msg = new ChatMessage("YouTube", author, text);
                        main.post(() -> messages.accept(msg));
                    }
                }
                pageToken = data.optString("nextPageToken", pageToken);
                pollDelay = Math.max(2000, Math.min(data.optLong("pollingIntervalMillis", 5000), 30000));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "connection error" : e.getMessage();
                main.post(() -> status.accept("YouTube: " + message));
                if (message.contains("HTTP 401") || message.contains("HTTP 403") || message.contains("HTTP 404")) break;
                pollDelay = 8000;
            } finally {
                if (connection != null) connection.disconnect();
            }
            try { Thread.sleep(pollDelay); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
        }
    }

    @Override public void stop() {
        stopped = true;
        worker.shutdownNow();
    }
}
