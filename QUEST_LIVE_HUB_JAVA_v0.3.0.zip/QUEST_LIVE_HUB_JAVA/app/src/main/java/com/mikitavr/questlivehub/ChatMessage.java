package com.mikitavr.questlivehub;

public final class ChatMessage {
    public final String platform;
    public final String author;
    public final String text;
    public final long timestamp;

    public ChatMessage(String platform, String author, String text) {
        this.platform = platform;
        this.author = author;
        this.text = text;
        this.timestamp = System.currentTimeMillis();
    }
}
