package com.mikitavr.questlivehub;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayDeque;
import java.util.Random;

public class MainActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayDeque<ChatMessage> messages = new ArrayDeque<>();
    private final Random random = new Random();
    private LinearLayout messageList;
    private TextView status, count;
    private Spinner provider;
    private EditText channel, username, token;
    private ChatClient activeClient;
    private boolean wristMode = false;
    private final String[] demoNames = {"Nova", "PixelFox", "MikaVR", "CloudByte", "StarPlayer"};
    private final String[] demoTexts = {"Let's go!!", "Nice stream ✨", "GG", "Hello from Quest!", "That was amazing", "W chat 💙"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        setStatus("Ready · choose Demo or connect a provider");
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(29, 91, 133)));
        return b;
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(14); e.setHint(hint);
        e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF8192B0);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(bg(0xFF17243B, 12));
        if (secret) e.setInputType(0x00000081);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(46));
        p.bottomMargin = dp(7);
        e.setLayoutParams(p);
        return e;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setBackgroundColor(0xFF080D1B);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("QUEST LIVE HUB  ●", 21, Color.WHITE, true);
        title.setTextColor(0xFF55CAFF);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(label("QUEST 2 · 3 · 3S", 12, 0xFF9CB0D4, false));
        root.addView(top);

        status = label("", 13, 0xFF8EDBFF, false);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(32)));

        provider = new Spinner(this);
        String[] providers = {"Demo", "Twitch", "YouTube", "TikTok (not enabled)"};
        provider.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, providers));
        root.addView(provider, new LinearLayout.LayoutParams(-1, dp(44)));

        channel = field("Twitch channel / YouTube liveChatId", false);
        username = field("Twitch account username", false);
        token = field("OAuth access token (session only)", true);
        root.addView(channel); root.addView(username); root.addView(token);

        LinearLayout actions = new LinearLayout(this);
        Button connect = button("CONNECT");
        Button demo = button("DEMO");
        Button stop = button("STOP");
        Button wrist = button("COMPACT LAYOUT");
        actions.addView(connect, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(demo, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(actions);
        root.addView(wrist, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView chatTitle = label("LIVE CHAT", 15, Color.WHITE, true);
        header.addView(chatTitle, new LinearLayout.LayoutParams(0, dp(36), 1));
        count = label("0 / 80", 12, 0xFF8192B0, false);
        header.addView(count);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        messageList = new LinearLayout(this);
        messageList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(messageList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        root.addView(label("Soft neon interface · credentials kept in memory only", 10, 0xFF71809C, false));
        setContentView(root);

        connect.setOnClickListener(v -> connectSelected());
        demo.setOnClickListener(v -> startDemo());
        stop.setOnClickListener(v -> stopAll());
        wrist.setOnClickListener(v -> {
            wristMode = !wristMode;
            root.setPadding(dp(wristMode ? 5 : 16), dp(wristMode ? 5 : 12), dp(wristMode ? 5 : 16), dp(12));
            setStatus(wristMode ? "Compact layout preview · not wrist anchored" : "Standard layout");
        });
    }

    private void setStatus(String text) { status.setText(text); }

    private void addMessage(ChatMessage msg) {
        runOnUiThread(() -> {
            if (messages.size() >= 80) messages.removeFirst();
            messages.addLast(msg);
            TextView card = label(msg.platform + "  ·  " + msg.author + "\n" + msg.text, 14, 0xFFF0F4FF, false);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackground(bg(0xFF19263E, 12));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.bottomMargin = dp(7);
            messageList.addView(card, 0, p);
            while (messageList.getChildCount() > 80) messageList.removeViewAt(messageList.getChildCount() - 1);
            count.setText(messages.size() + " / 80");
        });
    }

    private final Runnable demoTick = new Runnable() {
        @Override public void run() {
            addMessage(new ChatMessage("Demo", demoNames[random.nextInt(demoNames.length)],
                    demoTexts[random.nextInt(demoTexts.length)]));
            main.postDelayed(this, 1700);
        }
    };

    private void startDemo() {
        stopAll();
        setStatus("Demo chat running");
        main.post(demoTick);
    }

    private void connectSelected() {
        stopAll();
        String selected = String.valueOf(provider.getSelectedItem());
        String room = channel.getText().toString().trim();
        String user = username.getText().toString().trim();
        String accessToken = token.getText().toString().trim();
        if ("Twitch".equals(selected)) {
            activeClient = new TwitchChatClient(room, user, accessToken, this::addMessage, this::setStatus);
        } else if ("YouTube".equals(selected)) {
            activeClient = new YouTubeChatClient(room, accessToken, this::addMessage, this::setStatus);
        } else {
            setStatus("Choose Twitch or YouTube. TikTok needs an approved official integration.");
            return;
        }
        activeClient.start();
    }

    private void stopAll() {
        main.removeCallbacks(demoTick);
        if (activeClient != null) { activeClient.stop(); activeClient = null; }
        setStatus("Disconnected");
    }

    @Override protected void onDestroy() {
        stopAll();
        super.onDestroy();
    }
}
