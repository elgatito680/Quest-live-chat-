package com.mikitavr.questlivehub;

public interface ChatClient {
    void start();
    void stop();
}
