package com.mikitavr.questlivehub;

import android.os.Handler;
import android.os.Looper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public final class TwitchChatClient implements ChatClient {
    public interface MessageSink { void accept(ChatMessage message); }
    public interface StatusSink { void accept(String status); }
    private final String channel, username, token;
    private final MessageSink messages;
    private final StatusSink status;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient client = new OkHttpClient();
    private WebSocket socket;

    public TwitchChatClient(String channel, String username, String token, MessageSink messages, StatusSink status) {
        this.channel = channel == null ? "" : channel.replace("#", "").trim().toLowerCase();
        this.username = username == null ? "" : username.replace("@", "").trim().toLowerCase();
        this.token = token == null ? "" : token.trim().replaceFirst("(?i)^oauth:", "");
        this.messages = messages; this.status = status;
    }

    @Override public void start() {
        if (channel.isEmpty() || username.isEmpty() || token.isEmpty()) {
            status.accept("Twitch requires channel, username and OAuth token."); return;
        }
        status.accept("Twitch: connecting…");
        Request request = new Request.Builder().url("wss://irc-ws.chat.twitch.tv:443").build();
        socket = client.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) {
                ws.send("PASS oauth:" + token);
                ws.send("NICK " + username);
                ws.send("JOIN #" + channel);
                main.post(() -> status.accept("Twitch: connected to #" + channel));
            }
            @Override public void onMessage(WebSocket ws, String text) {
                if (text.startsWith("PING")) { ws.send("PONG :tmi.twitch.tv"); return; }
                for (String line : text.split("\\r?\\n")) {
                    if (line.contains(" PRIVMSG #")) {
                        int prefix = line.startsWith("@") ? line.indexOf(" :") + 2 : 0;
                        int bang = line.indexOf('!', prefix);
                        int marker = line.indexOf(" PRIVMSG #", prefix);
                        int body = line.indexOf(" :", marker);
                        if (bang > 1 && body > marker) {
                            String author = line.substring(1, bang);
                            String message = line.substring(body + 2);
                            main.post(() -> messages.accept(new ChatMessage("Twitch", author, message)));
                        }
                    } else if (line.startsWith("PING")) ws.send("PONG :tmi.twitch.tv");
                }
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                main.post(() -> status.accept("Twitch connection failed: check token, channel and network."));
            }
        });
    }

    @Override public void stop() {
        if (socket != null) { socket.close(1000, "User disconnected"); socket = null; }
        client.dispatcher().cancelAll();
    }
}
