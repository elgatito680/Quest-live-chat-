# Keep default Android rules for this prototype.
