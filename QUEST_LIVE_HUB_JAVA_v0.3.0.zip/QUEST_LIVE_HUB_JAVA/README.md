# QUEST LIVE HUB — Native Java Android project

Native Android application written in Java, built with Gradle and intended for Android CI.

## Features in this source build

- Native Android UI with a dark neon chat panel.
- Demo chat mode.
- Twitch IRC over secure WebSocket using OkHttp.
- YouTube Live Chat polling using the official YouTube Data API.
- TikTok shown as unavailable until an approved official integration is available.
- Session-only access tokens (not persisted).
- Bounded display history (80 messages).
- Horizon OS overlay-launcher manifest alias for Quest 2, Quest 3 and Quest 3S.

## Important limitations

- This is a native 2D Android panel. The Meta overlay launcher integration is experimental and has not been built or tested on a physical Quest headset.
- The overlay is user-launched from Horizon OS. It is not an unrestricted Android "draw over other apps" permission.
- The compact layout is only a UI layout; it is not physically attached to the wrist.
- Chat polling/WebSocket operation is tied to the activity process in this starter. It is not a persistent background service.
- Twitch and YouTube connections require valid credentials. OAuth sign-in/refresh flows are not included; tokens are entered manually and held in memory.
- TikTok Live chat is not implemented. Do not use unofficial scraping endpoints.
- No APK is included in this source archive. Android CI must build it.

## Build locally

Requirements: JDK 17 and Android SDK platform 35.

```bash
./gradlew assembleDebug
```

If you do not have a Gradle wrapper in your checkout, use Android Studio to import this project or generate a wrapper with Gradle 8.7:
```bash
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions

Push the full repository to GitHub. Open **Actions** and run the **Android CI** workflow. The APK is uploaded as an artifact named `quest-live-hub-debug-apk`.

## Credentials

Never commit OAuth tokens, API secrets, signing keys or passwords. For a public production app, implement provider OAuth flows and secure token storage. Do not embed a client secret in the APK.

## Horizon OS overlay

The manifest declares Meta Horizon SDK metadata and an activity alias with:
- `com.oculus.intent.category.2D`
- `com.oculus.intent.category.OVERLAY_LAUNCHER`

This follows Meta's overlay-launcher pattern but remains unverified in this project. Confirm current Meta SDK requirements and test on actual supported headset firmware before release. The prohibited `SYSTEM_ALERT_WINDOW` permission is intentionally not requested.
